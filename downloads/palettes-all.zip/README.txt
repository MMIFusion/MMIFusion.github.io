MMIFusion 配色库 / CC BY 4.0

132 组基础色系，132 组组会配色，每组 5 色。
基础色系从浅到深；组会配色用于类别与模块区分，不代表数值大小。
单卡 JSON 含使用建议、RGB 和建议字色；SVG 可直接编辑。
CSV 可在 Excel 中打开；整体 JSON 便于 Python、Matplotlib 与网页复用。
浅色在白底上宜用于填充，细线请优先选深色；曲线配合线型和标记。
本站原创搭配，不是论文取色，也未声明全部色板满足色觉障碍可分辨性。
来源：https://mmifusion.github.io/palettes.html
